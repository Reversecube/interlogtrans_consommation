# -*- coding: utf-8 -*-
from . import fuel_consumption
